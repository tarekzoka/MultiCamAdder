from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigInteger, getConfigListEntry
from Components.Console import Console
from Components.Label import Label
import subprocess

class PortConfigInteger(ConfigInteger):
    def __init__(self, default=0):
        ConfigInteger.__init__(self, default=default, limits=(0, 65535))

    def getText(self):
        return str(int(self.value)) if self.value != 0 else "0"

class MultiCamAdderScreen(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="800,600" title="MultiCamAdder">
            <widget name="config" position="30,30" size="760,450"
                itemHeight="90" font="Bold;40" scrollbarMode="showOnDemand"/>
            <widget name="key_red" position="20,510" size="250,50" font="Bold;28" 
                halign="center" valign="center" backgroundColor="red" foregroundColor="white"/>
            <widget name="key_green" position="290,510" size="150,50" font="Bold;28" 
                halign="center" valign="center" backgroundColor="#006400" foregroundColor="white"/>
            <widget name="key_yellow" position="460,510" size="150,50" font="Bold;28" 
                halign="center" valign="center" backgroundColor="#B8860B" foregroundColor="white"/>
            <widget name="key_blue" position="630,510" size="150,50" font="Bold;28" 
                halign="center" valign="center" backgroundColor="blue" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)
        self["actions"] = ActionMap(["ColorActions", "SetupActions"], {
            "red": self.checkExistingServers,
            "green": self.saveSettings,
            "yellow": self.convertToNewcamd,
            "blue": self.checkConnection,
            "cancel": self.exit,
            "ok": self.openKeyboard
        }, -2)
        
        self["key_red"] = Label("Check_Servers")
        self["key_green"] = Label("Cccam")
        self["key_yellow"] = Label("Newcamd")
        self["key_blue"] = Label("Check")

        self.server_host = ConfigText(default="server.example.com", fixed_size=False)
        self.server_port = PortConfigInteger(default=12345)
        self.server_user = ConfigText(default="username", fixed_size=False)
        self.server_pass = ConfigText(default="password", fixed_size=False)

        self.list = [
            getConfigListEntry("Server Host:", self.server_host),
            getConfigListEntry("Server Port:", self.server_port),
            getConfigListEntry("Username:", self.server_user),
            getConfigListEntry("Password:", self.server_pass),
        ]

        ConfigListScreen.__init__(self, self.list)

    def has_data_changed(self):
        default_host = "server.example.com"
        default_port = 12345
        default_user = "username"
        default_pass = "password"
        return (self.server_host.value != default_host or
                self.server_port.value != default_port or
                self.server_user.value != default_user or
                self.server_pass.value != default_pass)

    def openKeyboard(self):
        current_item = self["config"].getCurrent()
        if current_item:
            current_config = current_item[1]
            current_value = str(int(current_config.value)) if isinstance(current_config, PortConfigInteger) else str(current_config.value)
            self.session.openWithCallback(
                lambda text: self.keyboardCallback(text, current_config),
                VirtualKeyBoard,
                title=f"Enter {current_item[0]}",
                text=current_value
            )

    def keyboardCallback(self, text, config_item):
        if text is not None:
            try:
                if isinstance(config_item, PortConfigInteger):
                    config_item.value = int(text.lstrip('0') or 0)
                else:
                    config_item.value = text
                self["config"].invalidateCurrent()
            except ValueError:
                self.session.open(MessageBox, "Invalid input! Please enter a valid number.", MessageBox.TYPE_ERROR, timeout=3)

    def saveSettings(self):
        if not self.has_data_changed():
            self.session.open(MessageBox, "Please modify all default values before saving.", MessageBox.TYPE_ERROR, timeout=3)
            return
        try:
            port_value = int(self.server_port.value)
        except ValueError:
            self.session.open(MessageBox, "Invalid port value!", MessageBox.TYPE_ERROR, timeout=3)
            return
        self.writeConfigFile("cccam")
        self.session.open(MessageBox, "Server Added Successfully!", MessageBox.TYPE_INFO, timeout=3)
        Console().ePopen("/usr/lib/enigma2/python/Plugins/Extensions/MultiCamAdder/script.sh")

    def convertToNewcamd(self):
        if not self.has_data_changed():
            self.session.open(MessageBox, "Please modify all default values before converting.", MessageBox.TYPE_ERROR, timeout=3)
            return
        try:
            port_value = int(self.server_port.value)
        except ValueError:
            self.session.open(MessageBox, "Invalid port value!", MessageBox.TYPE_ERROR, timeout=3)
            return
        self.writeConfigFile("newcamd")
        self.session.open(MessageBox, "Converted to Newcamd Successfully!", MessageBox.TYPE_INFO, timeout=3)

    def checkConnection(self):
        host = self.server_host.value
        port = self.server_port.value
        try:
            result = subprocess.run(["telnet", host, str(port)], timeout=3, capture_output=True, text=True)
            if "Connected" in result.stdout or "Escape character is" in result.stdout:
                self.session.open(MessageBox, f"✅ Server: {host}:{port} - Connected", MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(MessageBox, f"❌ Server: {host}:{port} - No Connection", MessageBox.TYPE_ERROR, timeout=3)
        except subprocess.TimeoutExpired:
            self.session.open(MessageBox, f"❌ Server: {host}:{port} - Connection Timeout", MessageBox.TYPE_ERROR, timeout=3)
        except Exception as e:
            self.session.open(MessageBox, f"Error checking connection: {str(e)}", MessageBox.TYPE_ERROR, timeout=3)

    def checkExistingServers(self):
        config_paths = [
            "/etc/CCcam.cfg",
            "/etc/tuxbox/config/CCcam.cfg"
        ]
        servers = []
        for path in config_paths:
            try:
                with open(path, "r") as f:
                    for line in f:
                        if line.strip().startswith("C: "):
                            parts = line.strip().split()
                            if len(parts) >= 3:
                                servers.append((parts[1], parts[2]))
            except FileNotFoundError:
                continue
        if not servers:
            self.session.open(MessageBox, "No servers found in CCcam.cfg files!", MessageBox.TYPE_INFO, timeout=3)
            return
        results = []
        for host, port in servers:
            try:
                result = subprocess.run(["telnet", host, port], timeout=3, capture_output=True, text=True)
                if "Connected" in result.stdout or "Escape character is" in result.stdout:
                    results.append(f"✅ {host}:{port} - Connected")
                else:
                    results.append(f"❌ {host}:{port} - No Connection")
            except subprocess.TimeoutExpired:
                results.append(f"❌ {host}:{port} - Timeout")
            except Exception as e:
                results.append(f"❌ {host}:{port} - Error: {str(e)}")
        self.session.open(MessageBox, "\n".join(results) if results else "No servers to check!", MessageBox.TYPE_INFO, timeout=10)

    def writeConfigFile(self, protocol):
        data = {
            "SERVER_HOST": self.server_host.value,
            "SERVER_PORT": str(int(self.server_port.value)),
            "SERVER_USER": self.server_user.value,
            "SERVER_PASS": self.server_pass.value
        }
        config_paths = {
            "cccam": [
                "/etc/tuxbox/config/ncam.server",
                "/etc/tuxbox/config/oscam.server",
                "/etc/tuxbox/config/CCcam.cfg",
                "/etc/CCcam.cfg"
            ],
            "newcamd": [
                "/etc/tuxbox/config/ncam.server",
                "/etc/tuxbox/config/oscam.server",
                "/etc/tuxbox/config/CCcam.cfg",
                "/etc/CCcam.cfg"
            ]
        }
        for path in config_paths[protocol]:
            try:
                if "CCcam.cfg" in path or "cccam.cfg" in path:
                    content = f"C: {data['SERVER_HOST']} {data['SERVER_PORT']} {data['SERVER_USER']} {data['SERVER_PASS']}\n" if protocol == "cccam" else f"N: {data['SERVER_HOST']} {data['SERVER_PORT']} {data['SERVER_USER']} {data['SERVER_PASS']} 01 02 03 04 05 06 07 08 09 10 11 12 13 14\n"
                else:
                    content = f"""
[reader]
label                         = My_Server
protocol                      = {protocol}
device                        = {data['SERVER_HOST']},{data['SERVER_PORT']}
user                          = {data['SERVER_USER']}
password                      = {data['SERVER_PASS']}
""" + ("group                         = 1,2,3,4,5,6,7,8,9,10,64\nemmcache                      = 2,1,2,1\ncccversion                    = 2.0.11\nccckeepalive                  = 1\ncccmaxhops                    = 2\ndisablecrccws                 = 1\ncccwantemu                    = 1\nblockemm-unknown              = 1\nblockemm-u                    = 1\nblockemm-s                    = 1\nblockemm-g                    = 1\naudisabled                    = 1\nservices                      = !powervu_fake,!tandberg_fake,!biss_fake,!afn_fake,1708:000000\ndisablecrccws_only_for        = 1709:000000;1708:000000;1811:003311,003315;09C4:000000;0500:030B00,042820;0604:000000;1819:00006D;0100:00006D;1810:000000;1884:000000;0E00:000000" if protocol == "cccam" else "key                           = 0102030405060708091011121314\nfallback                      = 1\ngroup                         = 1,2,3,4,5,6,7,8,9,10,64\naudisabled                    = 1\ndisablecrccws_only_for        = 1709:000000;1708:000000;1811:003311,003315;09C4:000000;0500:030B00,042820;0604:000000;1819:00006D;0100:00006D;1810:000000;1884:000000;0E00:000000")
                with open(path, "a") as f:
                    f.write(content)
            except IOError:
                pass

    def exit(self):
        self.close()

def Plugins(**kwargs):
    return [PluginDescriptor(name="MultiCamAdder",
                             description="Add NCam, OScam, and CCcam servers",
                             where=PluginDescriptor.WHERE_PLUGINMENU,
                             icon="/usr/lib/enigma2/python/Plugins/Extensions/MultiCamAdder/icon.png",
                             fnc=lambda session, **kwargs: session.open(MultiCamAdderScreen))]



